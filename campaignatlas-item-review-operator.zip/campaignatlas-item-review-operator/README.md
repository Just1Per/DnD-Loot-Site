# CampaignAtlas read-only item review capture

Follow docs/item-catalogue-operator-handoff.md. This bundle contains code, sanitized historical review metadata, and licensed SRD replacement proposals. It contains no private original exports, campaign identifiers or credentials.

From this directory, install dependencies with `npm ci --prefix functions --no-audit --no-fund` and run `node --test tests/item-catalogue-decisions.cjs tests/srd-replacement-batch.cjs tests/item-catalogue-migration.cjs tests/item-catalogue-audit.cjs tests/item-catalogue-review.cjs`.

Only the `capture` command in the handoff is intended for the initial owner action. It does not write to Firebase. Do not run a production migration apply command.
