# CampaignAtlas — authorized private-library migration

Follow docs/authorized-library-migration.md. The owner delegated adoption of the exact 659 recommendations: 302 SRD replacements and 357 shared retirements. All originals and generated illustrations are privately preserved before shared changes. Existing campaigns and character equipment are left in place.

Use Ubuntu/WSL, Linux or macOS. Native Windows permission masks are unsupported. Node 22/24 and Google Cloud CLI must be available in that same environment.

From this folder:

    npm ci --prefix functions --no-audit --no-fund
    gcloud auth application-default login
    node scripts/prepare-authorized-library-migration.mjs prepare --campaign YOUR_EXISTING_CAMPAIGN_ID

Prepare makes no Firestore/Storage writes. It captures fresh originals, verifies source checksums/revisions and generates the authorized manifest and immutable plan privately under your home folder. Share only shareable-library-plan-status.json. Keep the snapshot, decisions, plan and backups private.

Check and apply commands are in docs/authorized-library-migration.md. Only apply changes production; it needs the exact generated plan digest. Both Firestore and Storage private-library rules must be updated separately. The package never deploys rules.

Offline tests: node --test tests/authorized-library-migration.cjs tests/private-item-library.cjs tests/item-catalogue-migration.cjs

This package contains no production exports, destination identifiers, private images or credentials. Bundled SRD sources are pinned and checksum verified; source documents and replacement attribution include the Wizards of the Coast SRD attribution and CC BY 4.0 source/license links. See data/rules/srd-magic-item-text-hashes.json and the bundled source Document files.
